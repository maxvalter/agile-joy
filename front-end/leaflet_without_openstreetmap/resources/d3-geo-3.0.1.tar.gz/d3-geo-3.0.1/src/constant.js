export default function(x) {
  return function() {
    return x;
  };
}
